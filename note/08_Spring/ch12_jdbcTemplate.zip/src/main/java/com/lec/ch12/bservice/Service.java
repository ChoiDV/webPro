package com.lec.ch12.bservice;
import org.springframework.ui.Model;
public interface Service {
	public void execute(Model model);
}

package com.lec.ch11.bservice;
import org.springframework.ui.Model;
public interface Service {
	public void execute(Model model);
}
